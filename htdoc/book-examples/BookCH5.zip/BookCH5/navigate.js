// navigate.js
//  An example of using the navigator object
// The event handler function to display the browser name
//  and its version number
function navProperties() {
  alert("The browser is: " + navigator.appName + "\n" +
    "The version number is: " + navigator.appVersion + "\n");
}

 