// load.js
//   An example to illustrate the load event
      
// The onload event handler

function load_greeting () {
  alert("You are visiting the home page of \n" +
        "Pete's Pickled Peppers \n" + "WELCOME!!!");
}
