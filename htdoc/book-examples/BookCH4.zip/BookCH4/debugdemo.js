// debugdemo.js
//   An example to illustrate debugging help 

var row;
row = 0;

while(row != 4 {
  document.write("row is ", row, "<br />");
  row++;
}
