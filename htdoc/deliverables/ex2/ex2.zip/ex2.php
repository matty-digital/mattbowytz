<!DOCTYPE html>
<html>
 <head>
  <title>Simple PHP Example</title>
 </head>
 <body>
    <?php 
      echo "<p><h1>Output</h1>";
      echo "<h2>Output</h2>";
      echo "<h3>Output</h3></p>";
    ?>
    <script language="PHP">
      echo "\n<b>More PHP Output</b>\n";
      echo "New line in source but not rendered";
      echo "<br/>";
      echo "New line rendered but not in source";
    </script>
 </body>
</html>
