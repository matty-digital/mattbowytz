<?php
interface Comparable
{
   public function compareTo($r);
}
