CREATE DATABASE Wacky;
GRANT ALL on Wacky.* to Wacky@localhost IDENTIFIED by 'wacky-man';
CREATE DATABASE Zany;
GRANT ALL on Zany.* to Zany@localhost IDENTIFIED by 'zany-man';
