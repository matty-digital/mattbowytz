CREATE DATABASE ComicBooks;
GRANT ALL on ComicBooks.* to bowytz@localhost IDENTIFIED by 'bowytz';
CREATE DATABASE Collectibles;
GRANT ALL on Collectibles.* to bowytz@localhost IDENTIFIED by 'bowytz';
